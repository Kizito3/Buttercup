const start = document.querySelector(".val__btn"),
  firstBtn = document.querySelector(".val__btn2"),
  secondBtn = document.querySelector(".val__btn3"),
  thirdBtn = document.querySelector(".val__btn4"),
  fourthBtn = document.querySelector(".val__btn5"),
  fifthBtn = document.querySelector(".val__btn6"),
  sixthBtn = document.querySelector(".val__btn7"),
  seventhBtn = document.querySelector(".val__btn8"),
  eighthBtn = document.querySelector(".val__btn9"),
  ninethBtn = document.querySelector(".val__btn10"),
  tenthBtn = document.querySelector(".val__btn11"),
  eleventhBtn = document.querySelector(".val__btn12"),
  twelvethBtn = document.querySelector(".val__btn13"),
  thirteenthBtn = document.querySelector(".val__btn14"),
  fourteenthBtn = document.querySelector(".val__btn15"),
  fifteenBtn = document.querySelector(".val__btn16"),
  first = document.querySelector(".first"),
  second = document.querySelector(".second"),
  third = document.querySelector(".third"),
  fourth = document.querySelector(".fourth"),
  fifth = document.querySelector(".fifth"),
  sixth = document.querySelector(".sixth"),
  seventh = document.querySelector(".seventh"),
  nineth = document.querySelector(".nineth"),
  tenth = document.querySelector(".tenth"),
  eleventh = document.querySelector(".eleventh"),
  twelveth = document.querySelector(".twelveth"),
  thirteenth = document.querySelector(".thirteenth"),
  fourteenth = document.querySelector(".fourteenth"),
  fifteenth = document.querySelector(".fifteenth"),
  sixteenth = document.querySelector(".sixteenth"),
  seventeen = document.querySelector(".seventeen"),
  eighth = document.querySelector(".eighth");

start.addEventListener("click", () => {
  first.style.display = "none";
  second.style.display = "flex";
});

firstBtn.addEventListener("click", () => {
  second.style.display = "none";
  third.style.display = "flex";
});

secondBtn.addEventListener("click", () => {
  third.style.display = "none";
  fourth.style.display = "flex";
});
thirdBtn.addEventListener("click", () => {
  fourth.style.display = "none";
  fifth.style.display = "flex";
});
fourthBtn.addEventListener("click", () => {
  fifth.style.display = "none";
  sixth.style.display = "flex";
});
fifthBtn.addEventListener("click", () => {
  sixth.style.display = "none";
  seventh.style.display = "flex";
});

sixthBtn.addEventListener("click", () => {
  seventh.style.display = "none";
  eighth.style.display = "flex";
});

seventhBtn.addEventListener("click", () => {
  eighth.style.display = "none";
  nineth.style.display = "flex";
});

eighthBtn.addEventListener("click", () => {
  nineth.style.display = "none";
  tenth.style.display = "flex";
});

ninethBtn.addEventListener("click", () => {
  tenth.style.display = "none";
  eleventh.style.display = "flex";
});

tenthBtn.addEventListener("click", () => {
  eleventh.style.display = "none";
  twelveth.style.display = "flex";
});

eleventhBtn.addEventListener("click", () => {
  twelveth.style.display = "none";
  thirteenth.style.display = "flex";
});

twelvethBtn.addEventListener("click", () => {
  thirteenth.style.display = "none";
  fourteenth.style.display = "flex";
});

thirteenthBtn.addEventListener("click", () => {
  fourteenth.style.display = "none";
  fifteenth.style.display = "flex";
});
fourteenthBtn.addEventListener("click", () => {
  fifteenth.style.display = "none";
  sixteenth.style.display = "flex";
});

fifteenBtn.addEventListener("click", () => {
    sixteenth.style.display = "none";
  seventeen.style.display = "flex";
});
